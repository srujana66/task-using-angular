var express = require('express');
var router = express.Router();
var monk = require ('monk');
var db=monk('localhost:27017/airinusers');
var collection=db.get('logindetails');
var nodemailer = require('nodemailer')
var ran = require('randomstring')

/* GET home page. */
// router.get('/', function(req, res, next) {            				
//   res.render('index', { title: 'World' });
// });

module.exports = router;
// collection.insert({"email":req.body.em});
// collection.insert({"password":req.body.pass});

// router.get('/login',function(req,res){
// 	res.render('login');
// });

router.get('/table', function(req, res, next) {
  res.render('table');
});


router.post('/register', function(req, res) {  
collection.insert(req.body,function(err,docs){
    if(err)
    {
        console.log(err);
    }
    else{
        console.log(docs);
        res.redirect('/');
    }
  });
console.log(req.body);
});

router.post('/signin', function(req, res) {  
collection.find({},function(err,docs){
    if(err)
    {
        console.log(err);
    }
    else{
        console.log(docs);
        res.redirect('/');
    }
  });
console.log(req.body);
});

router.get('/table', function(req, res, next) { 
  collection.find({},function(err,docs){
  	if(err)
  	{
  		console.log(err)
  	}
    else(docs)
    {
    	console.log(docs)
    	res.render('table', { "data":docs });
    }
  });
  });  

router.get('/', function(req, res, next) { 
  collection.find({},function(err,docs){
    if(err)
    {
      console.log(err)
    }
    else(docs)
    {
      console.log(docs)
      res.render('index');
    }
  });                   
  })                 


router.post('/remove',function(req,res){
  console.log(req.body.a);
  var nam = req.body.a;
  collection.remove({"pass":nam},function(err,docs){
    res.send(docs);
  });
});

router.post('/edit',function(req,res){
console.log(req.body.b);
var id = req.body.b;
collection.find({"pass":id},function(err,docs){
res.send(docs);
  });
});

router.post('/update',function(req,res){
var a=req.body.id
console.log(a)
collection.update({"_id":a},{$set:req.body},function(err,docs){
res.redirect('/table');  //or res.render('/')
});
});


router.get('/forgot', function(req, res, next) {
   res.render('forgot');
 });

router.post('/sendmail', function(req, res, next) {
var otp=ran.generate(7);
   console.log(req.body.email);
   var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'hemashreekt@gmail.com',
    pass: 'umadevi917*'
  }
});

var mailOptions = {
  from: 'hemashreekt@gmail.com',
  to: req.body.email,
  subject: 'Vetty verification	 OTP',
  text: 'Your code is:'+otp
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});
res.redirect('/')
 });